package fr.afpa.formation.squelette;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmallApp {
	
    public static void main(String[] args) {
        SpringApplication.run(SmallApp.class, args);
    }
}
